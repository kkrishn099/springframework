package com.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class Test {

	public static void main(String[] args) {
		// step 1 load the XML FILE
		String xml = "F:\\Spring_version5\\Spring_First\\src\\beans.xml";
		FileSystemResource fsr = new FileSystemResource(xml);

		BeanFactory factory = new XmlBeanFactory(fsr);
		BarBean bar = factory.getBean(BarBean.class);
		
		 System.out.println(bar.supply());
		 System.out.println(bar.getBarName());
		 System.out.println(bar.getLicNo());
		 System.out.println(bar.getLocation());
		 System.out.println(bar.getTurnOver());
		 System.out.println(bar.toString());

	}

}
