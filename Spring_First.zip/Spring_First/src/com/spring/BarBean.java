package com.spring;

import java.io.Serializable;

public class BarBean implements Serializable {
	
	private String barName;
	private String licNo;
	private String location;
	private int turnOver;
	
	
	
	
	public String supply() {
		return "Supplied Alcohol";
	}




	public String getBarName() {
		return barName;
	}




	public void setBarName(String barName) {
		this.barName = barName;
	}




	public String getLicNo() {
		return licNo;
	}




	public void setLicNo(String licNo) {
		this.licNo = licNo;
	}




	public String getLocation() {
		return location;
	}




	public void setLocation(String location) {
		this.location = location;
	}




	public int getTurnOver() {
		return turnOver;
	}




	public void setTurnOver(int turnOver) {
		this.turnOver = turnOver;
	}




	@Override
	public String toString() {
		return "BarBean [barName=" + barName + ", licNo=" + licNo + ", location=" + location + ", turnOver=" + turnOver
				+ "]";
	}

}
